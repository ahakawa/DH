// Exemplos de uso do objeto DATE:
let data = new Date();
console.log(data);

data.to;
